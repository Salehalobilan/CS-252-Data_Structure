public class Test {
    public static void main(String[] args) {
        DoublyLinkedList<Double> dll = new DoublyLinkedList<> ();
        dll.addLast(1.4);
        dll.addFirst(12.1);
        dll.addFirst(11.1);
        dll.addLast(13.4);
        dll.addLast(14.4);

        dll.print();

       // System.out.print("After removing \n");
       // dll.removeLast();
       // dll.print();

        System.out.print("middle Node \n" + dll.middle().getElement());
        
        dll.swapbetweenValues(11.1, 14.4);
        System.out.print("\nAfter swapping \n");
        dll.print();
        /*
        CircularlyLinkedList<Double> cll = new CircularlyLinkedList<>();
        cll.addFirst(1.3);
        cll.addFirst(0.3);
        cll.addLast(2.3);
        cll.print();
        System.out.print("After removing \n");
        cll.removeLast();
        cll.print();
        */

       /*
        SinglyLinkedList<Double> sll = new SinglyLinkedList<>();
        sll.add(0.4, 0);
        sll.addFirst(10.2);
        sll.addLast(12.4);
        sll.addFirst(9.2);
        sll.addFirst(1.2);
        sll.add(15.4, 3);
        sll.remove(1);
        System.out.println(sll.removeLast());
        System.out.println(sll.removeLast());
       // System.out.print(sll.isEmpty()? "Empty list" : "Not empty ");
       // System.out.println(sll.size());
       System.out.println(); 
        print(sll);
      //  sll.print();
      */
    }

    public static void print (SinglyLinkedList sll){
        sll.moveToStart();
        for(int i =0; i < sll.size(); i ++)
        {
            System.out.println(sll.getValue());
            sll.next();
        }
    }
    
}
