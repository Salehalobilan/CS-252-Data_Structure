public class CircularlyLinkedList<E> {
    private Node<E> tail = null;
    private int size=0;

    public CircularlyLinkedList(){} 

    public int size() {
        return size;

    }

    public boolean isEmpty() {
        return size == 0;
    }

    public E first() { // returns (but does not remove) the first element
        if (isEmpty()) {
            return null;
        }
        return tail.getNext().getElement();
    }

    public E last() { // returns (but does not remove) the last element
        if (isEmpty()) {
            return null;
        }
        return tail.getElement();
    }

    public void rotate(){
        if(tail != null)
        tail = tail.getNext(); 
    }

    public void addFirst(E e) { // adds element e to the front of the list
       // 
        if (size == 0) {
            tail = new Node<>(e, null); // create and link a new node
            tail.setNext(tail); // special case: new node becomes tail also
        } else {
            Node<E> newest = new Node<>(e, tail.getNext()); 
            tail.setNext(newest);  
        }
        size++;
    }

    public void addLast(E e) {
        addFirst(e);
        tail = tail.getNext();
    }
    public void print (){
        if (isEmpty()) return ; 

        Node<E> curr = tail.getNext(); 

        while(curr != tail){
            System.out.println(curr.getElement());
            curr = curr.getNext();
        }
        System.out.println(curr.getElement());
    }

    public E removeFirst() { // removes and returns the first element
        if (isEmpty()) {
            return null; // nothing to remove
        }
        Node<E> head = tail.getNext(); 
        E answer = head.getElement();
       // head = head.getNext(); // will become null if list had only one node
        size--;
        if(head == tail ) tail = null; 
        /*
        if (size == 0) {
            tail = null; // special case as list is now empty
        }*/
        else {
            tail.setNext(head.getNext());
        }
        
        return answer;
    }

    public E removeLast(){
        if(isEmpty()) return null; 

        size--; 
        E element = tail.getElement();

        if(size == 0 ){
            tail =  null; 
        }        
        else {
            Node<E> w = tail.getNext(); 
            while (w.getNext() != tail){
                w = w.getNext(); 
            }
            w.setNext(w.getNext().getNext());
            
            tail = w ; 
        }


        return element; 

    }

    
}
