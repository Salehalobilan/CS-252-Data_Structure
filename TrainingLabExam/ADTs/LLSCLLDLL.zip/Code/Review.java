public class Review{

    public static void main(String[] args) {

        int [][] tda = new int [3][3];

        int [] [] tda2 = {{1,4,5},{2,2,4,5},{3,2,3,4}};

        for(int i= 0 ; i < tda2.length; i++){
            System.out.println();
            for(int j = 0 ; j<tda2[i].length;j++)
            System.out.print(tda2[i][j] + " ");
        }



        Integer [] ia = {2,3,4,5};
        printArray(ia);

        Double [] id = {2.1,3.2,4.0,5.11};
        printArray(id);

        Student [] star = new Student [2];
        star[0] = new UnSt (1223,"Ahemd",4);
        star[1] = new GradSt (122231,"FAHD", "data");



        for(Student s:star){
            if (s instanceof  UnSt){
                UnSt us = (UnSt) s; 
                   
                System.out.println("UnderGraduate Student no course " + us.getNofcourses());
                us.setNofcourses(5); 

            }
        }
                    


       // System.out.println("student 1 " +star[0]);
       // System.out.println("student 2 " +star[1]);

        printArray(star);
        System.out.println("max " +max(id));

       // System.out.println("max " +max(star));

        G<Integer> gi = new G<> (10);
        G<Student> gs = new G<> (new Student(123344,"Saad"));

        G g2 = new G (10);
        
        System.out.println(gi);

        
    }

    public static void printArray(Object [] array){

        for(Object e:array)
        System.out.println(e +" ");

    }

    public static <T extends Comparable<T>> T  max(T [] array){
        T m = array [0];

        for(T e:array)
        if (m.compareTo(e) < 0  )
            m = e; 

        return m ; 

    }
}

class Student implements Comparable {
    int id;
    String name;
    Student (int id, String name){
        this.id = id ;
        this.name = name; 
    }

    @Override
    public String toString() {
        return String.format("Student id %d, name %s", id, name);
    }

    @Override
    public int compareTo(Object o) {
        Student st = (Student) o;
        if (st.id <this.id) return 1;
        if (st.id >this.id) return -1;

        return 0;
    }
}

class UnSt extends Student {
    int nofcourses;
    UnSt(int id, String name, int noc){
        super(id, name);
        this.nofcourses = noc; 
    }

    public int getNofcourses() {
        return nofcourses;
    }

    public void setNofcourses(int nofcourses) {
        this.nofcourses = nofcourses;
    }

    @Override
    public String toString() {
        return String.format("%s -nofcourses %d", super.toString(), nofcourses);
    }

}

class GradSt extends Student {
    String thesis; 
    GradSt(int id, String name, String th){
        super(id, name);
        this.thesis = th; 
    }

    @Override
    public String toString() {
        return String.format("%s -thesis %s", super.toString(), thesis);
    }
    
}

class G <T> {
    T element ; 
    G(T e ){
        this.element = e; 
    }


    @Override
    public String toString() {
        return String.format("value %s", element);
    }


}