public class DoublyLinkedList<E> {
    
    private NodeD<E> head;
    private NodeD<E> tail;
    private int size=0;

   public DoublyLinkedList(){
        head = new NodeD<>(null, null, null);
        tail = new NodeD<>(null, head, null);
        head.setNext(tail);
    }

    public int size() {
        return size;
    }

    public boolean isEmpty() {
        return size == 0;
    }

    public E first() { // returns (but does not remove) the first element
        if (isEmpty()) {
            return null;
        }
        return head.getNext().getElement();
    }

    public E last() { // returns (but does not remove) the last element
        if (isEmpty()) {
            return null;
        }
        return tail.getPrev().getElement();
    }

    public void addFirst(E e){
        addBetween(e, head, head.getNext());
    }

    public void addLast(E e){
        addBetween(e, tail.getPrev(),tail);
    }

    private void addBetween(E e, NodeD<E> pre, NodeD<E> succ){
        NodeD<E> newest = new NodeD<>(e, pre, succ);
        pre.setNext(newest);
        succ.setPrev(newest);
        size++; 
    }

    public E removeFirst() { // removes and returns the first element
        if (isEmpty()) {
            return null; // nothing to remove
        }
        return remove(head.getNext());
        
    }


    public E removeLast(){
        if(isEmpty()) return null; 
       return remove(tail.getPrev());
    }

    private E remove(NodeD<E> removedNode){
        NodeD<E> pre =removedNode.getPrev();
        NodeD<E> succ =removedNode.getNext(); 
        pre.setNext(succ);
        succ.setPrev(pre);
        size--; 
        return removedNode.getElement(); 
    }

    public void print (){
        NodeD<E> curr = head.getNext(); 

        while(curr != tail){
            System.out.println(curr.getElement());
            curr = curr.getNext();
        }
    }

    public void swapbetweenValues(E e1, E e2){
        NodeD<E> x = null , y = null ; 
        NodeD<E> h = head.getNext(); 
        for(int i =0 ; i < size ; i ++)
        {
            E t = h.getElement(); 
            if(t.equals(e1)  )  x = h;
            if(t.equals(e2)  )  y = h;
            h = h.getNext(); 
        }
        if (x == null && y == null ) return ; 

        swap(x, y);
    }
    private void swap(NodeD<E> x, NodeD<E> y ){
        if (x == y ) return ; 
        NodeD<E> x_pre = x.getPrev();
        NodeD<E> y_pre = y.getPrev(); 
         
         if(y_pre == x ){ // x = 1 , y =2 , L 1  2 

            x.setNext( y.getNext());
            y.setNext(x);
            x_pre.setNext(y);
            y.setPrev(x_pre);

         }else if ( x_pre == y ){
         // x = 1 , y =2 , L 2  1
            y.setNext( x.getNext());
            x.setNext(y);
            y_pre.setNext(x);
            x.setPrev(y_pre);
         }
         else {
         // x = 1 , y =4 , L 1 3 4 2
            NodeD<E> temp = x.getNext(); 
            x.setNext(y.getNext());
            y.setNext(temp);

            x_pre.setNext(y);
            y.setPrev(x_pre);

            y_pre.setNext(x);
            x.setPrev(y_pre);

         }
         x.getNext().setPrev(x);
         y.getNext().setPrev(y);

    }


    public NodeD<E> middle(){
        if(head.getNext() == tail ) return null; 

        /// 1 2 3 4 5 
        /// 1 2 3  4 
        NodeD<E> m1  = head.getNext(); 
        NodeD<E> m2 =  tail.getPrev(); 
        while (m1 != m2 && m1.getNext() != m2){
            m1 = m1.getNext();
            m2 = m2.getPrev();
        }
        return m1 ; 

    }

}
