public class NodeD <E>{
    
    private E element;
    private NodeD<E> next;
    private NodeD<E> prev;

    public NodeD(E element, NodeD<E> pre, NodeD<E> next) {
        this.element = element;
        this.next = next;
        this.prev = pre;
    }

    public void setElement(E element) {
        this.element = element;
    }

    public void setNext(NodeD<E> next) {
        this.next = next;
    }
    
    public E getElement() {
        return element;
    }

    public NodeD<E> getNext() {
        return next;
    } 
    public void setPrev(NodeD<E> prev) {
        this.prev = prev;
    }
    
    public NodeD<E> getPrev() {
        return prev;
    }
}